DEBUG = True
TESTING = True
USERNAME = 'testadmin'
PASSWORD = 'testpass'
SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/job_store.db'
NAME = 'testing'
_TEST_CALLBACK_URL = 'http://0.0.0.0:8721/test_callback_url'
